#pragma once

void wakenet_test();